import React from 'react';

const NightModeContext = React.createContext({
    status: "",
    setStatus : () => {},
})                
export default NightModeContext;
  