import _CardIcon from './CardIcon'
import _MenuOpenIcon from './MenuOpenIcon'
import _PenIcon from './PenIcon'
import _SecurityIcon from './SecurityIcon'
import _EyeIcon from './EyeIcon'

export const CardIcon =  _CardIcon
export const MenuOpenIcon = _MenuOpenIcon
export const PenIcon = _PenIcon
export const EyeIcon = _EyeIcon