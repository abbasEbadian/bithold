module.exports = {
  reactStrictMode: true,
    images: {
      loader: 'akamai',
      path: '', 
      domains: ['blog.bithold.exchange'],
  },
    experimental: {
    outputStandalone: true,
  }
}
